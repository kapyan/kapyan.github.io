#!/bin/bash

status_url="http://127.0.0.1/nginx_status"
case $1 in
	status)
		nginx_pid=$(ps -C nginx --no-heading|wc -l)
		if [ ${nginx_pid} -eq "0" ];then
			echo "stop"
		else
			echo "running"
		fi
		;;
	active_conn)
		curl $status_url 2>/dev/null|awk -F ":" 'NR==1{print $2}'
		;;
	accepts)
		curl $status_url 2>/dev/null|awk 'NR==3{print $1}'
		;;
	handled)
		curl $status_url 2>/dev/null|awk 'NR==3{print $2}'
		;;
	requests)
		curl $status_url 2>/dev/null|awk 'NR==3{print $3}'
		;;
	request_time)
		curl $status_url 2>/dev/null|awk 'NR==3{print $4}'
		;;
	reading)
		curl $status_url 2>/dev/null|awk 'NR==4{print $2}'
		;;
	writing)
		curl $status_url 2>/dev/null|awk 'NR==4{print $4}'
		;;
	waiting)
		curl $status_url 2>/dev/null|awk 'NR==4{print $6}'
		;;
	
		*)
		echo "$(basename $0) (status|active_conn|accepts|handled|requests|request_time|reading|writing|waiting)"
esac
